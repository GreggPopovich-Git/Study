package threadcode;
// 공유영역
public class SharedArea {
	Account account1;
	Account account2;
}
